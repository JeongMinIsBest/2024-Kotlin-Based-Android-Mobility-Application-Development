package com.example.newpractice

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import com.example.newpractice.ui.theme.NewpracticeTheme
import org.w3c.dom.Text

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        Log.d("Test", "onCreate()")

        val sendButton: Button = findViewById<Button>(R.id.sendbutton)

        sendButton.setOnClickListener {

            val disp: EditText = findViewById<EditText>(R.id.write)

            val sendMessage = disp.text.toString()
            val sendIntent = Intent(this, SubActivity::class.java) // this : 여기서 가져오겠다.

            sendIntent.putExtra("message", sendMessage)

            startActivity(sendIntent)

        }


    }

    override fun onStart() {
        super.onStart()
        Log.d("Test", "onStart()")
    }

    override fun onResume() {
        super.onResume()
        Log.d("Test", "onResume()")
    }

    override fun onPause() {
        super.onPause()
        Log.d("Test", "onPause()")
    }


}