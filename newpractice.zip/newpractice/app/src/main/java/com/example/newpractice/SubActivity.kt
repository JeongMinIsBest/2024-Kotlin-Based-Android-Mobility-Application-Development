package com.example.newpractice

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText

class SubActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_sub)

        val receivedIntent = getIntent()
        val receivedMessage = receivedIntent.getStringExtra("message")

        val receivedDisplaytxt = findViewById<EditText>(R.id.display)
        receivedDisplaytxt.setText(receivedMessage)


        // 나가기 버튼

        val exit: Button = findViewById<Button>(R.id.button)

        exit.setOnClickListener{
            finish()
        }
    }
}