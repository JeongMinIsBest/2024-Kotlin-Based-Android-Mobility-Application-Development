package com.example.greeting

import android.os.Bundle
import android.widget.Button
import androidx.activity.ComponentActivity

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.login)

        val loginButton: Button = findViewById(R.id.button2)

        loginButton.setOnClickListener {

            navigateToAnotherLayout()
        }
    }

    fun navigateToAnotherLayout() {
        setContentView(R.layout.account)
    }
}