package com.example.recycleview

import android.view.View
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.recycleview.data.Location
import org.w3c.dom.Text

class LocationViewHolder(view: View) : RecyclerView.ViewHolder(view) {

    private val name : TextView = view.findViewById(R.id.name)
    private val latitude : TextView = view.findViewById(R.id.latitude)
    private val longitude : TextView = view.findViewById(R.id.longitude)

    fun bind(location: Location) {

        name.text = location.name
        latitude.text = location.latitude.toString()
        longitude.text = location.longitude.toString()

    }
}